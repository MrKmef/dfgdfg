ZTUGAN – PUBLICERA GEMENSAMMA INLÄGG PÅ NETLIFY

Den här webbplatsen har Bara skriva + Netlify Function + Netlify Blobs.
För att inlägg ska synas för ALLA måste projektet publiceras som ett Netlify-projekt med serverfunktioner. Att bara ladda upp index.html fungerar inte.

VIKTIGT: Jag kan inte aktivera eller publicera något i ditt Netlify-konto härifrån.

REKOMMENDERAD PUBLICERING
1. Packa upp ZIP-filen.
2. Lägg ALLA filer från mappen i ett GitHub-repository.
3. Logga in på https://app.netlify.com/
4. Välj Add new site → Import an existing project → GitHub och välj repositoryt.
5. Kontrollera Build settings:
   - Build command: npm install
   - Publish directory: .
   - Functions directory: netlify/functions
6. Deploy och vänta tills bygget är klart.
7. Öppna din publicerade sida och testa Bara skriva.

TESTA FUNKTIONEN
Öppna:
https://DIN-SAJT/.netlify/functions/shared-writing

Byt DIN-SAJT mot din riktiga Netlify-adress.
- JSON som innehåller posts betyder att funktionen svarar.
- 404 betyder oftast att Functions inte publicerats.
- 500 betyder att serverfunktionen eller Blobs har ett fel; öppna Functions-loggarna i Netlify.

INLÄGG ÄR OFFENTLIGA
Alla som besöker sidan kan läsa meddelanden. Skriv inte lösenord, personuppgifter eller annat privat.

Filer som ska finnas i projektet:
index.html
package.json
netlify.toml
netlify/functions/shared-writing.js
netlify/functions/verify-code.js
netlify/functions/whitelist-request.js
