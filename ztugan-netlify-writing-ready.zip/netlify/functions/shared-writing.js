const { getStore } = require("@netlify/blobs");

const headers = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
const reply = (statusCode, body) => ({
  statusCode,
  headers,
  body: JSON.stringify(body)
});

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return reply(200, { ok: true });
  if (!["GET", "POST"].includes(event.httpMethod)) {
    return reply(405, { error: "Metoden stöds inte." });
  }

  try {
    const store = getStore("ztugan-public-posts");
    const posts = (await store.get("posts", { type: "json" })) || [];

    if (event.httpMethod === "GET") return reply(200, { posts });

    let data;
    try {
      data = JSON.parse(event.body || "{}");
    } catch {
      return reply(400, { error: "Ogiltig förfrågan." });
    }

    const name = String(data.name || "").trim().slice(0, 32);
    const text = String(data.text || "").trim();
    if (!text) return reply(400, { error: "Skriv ett meddelande först." });
    if (text.length > 1000) {
      return reply(400, { error: "Meddelandet får vara högst 1000 tecken." });
    }

    const post = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      name,
      text,
      createdAt: new Date().toISOString()
    };

    // Read latest posts immediately before writing to reduce lost updates.
    const latest = (await store.get("posts", { type: "json" })) || [];
    await store.setJSON("posts", [...latest, post].slice(-200));
    return reply(201, { ok: true, post });
  } catch (error) {
    console.error("shared-writing error:", error);
    return reply(500, {
      error: "Netlify kunde inte spara inlägget. Kontrollera att projektet publicerats via Netlify Build och att Netlify Blobs är tillgängligt. Se Functions-loggarna för detaljer."
    });
  }
};
