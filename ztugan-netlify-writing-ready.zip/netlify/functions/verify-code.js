exports.handler = async (event) => {
  const headers = { "Content-Type":"application/json", "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"Content-Type", "Access-Control-Allow-Methods":"POST, OPTIONS" };
  const reply = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });
  if (event.httpMethod === "OPTIONS") return reply(200, { ok:true });
  if (event.httpMethod !== "POST") return reply(405, { error:"Metoden stöds inte." });
  let data;
  try { data = JSON.parse(event.body || "{}"); } catch { return reply(400, { error:"Ogiltig förfrågan." }); }
  const submitted = String(data.code || "");
  const expected = process.env.WHITELIST_CODE || "";
  const invite = process.env.DISCORD_INVITE_URL || "";
  if (!expected || !invite) return reply(500, { error:"Whitelist är inte konfigurerad ännu." });
  if (!submitted || submitted.length > 80 || submitted !== expected) return reply(403, { error:"Koden stämmer inte." });
  return reply(200, { ok:true, invite });
};
