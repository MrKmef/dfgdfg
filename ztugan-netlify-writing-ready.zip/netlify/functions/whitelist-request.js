exports.handler = async (event) => {
  const headers = { "Content-Type":"application/json", "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"Content-Type", "Access-Control-Allow-Methods":"POST, OPTIONS" };
  const reply = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });
  if (event.httpMethod === "OPTIONS") return reply(200, { ok:true });
  if (event.httpMethod !== "POST") return reply(405, { error:"Metoden stöds inte." });
  const webhook = process.env.DISCORD_WEBHOOK_URL;
  if (!webhook) return reply(500, { error:"Ansökningsfunktionen är inte konfigurerad ännu." });
  let data;
  try { data = JSON.parse(event.body || "{}"); } catch { return reply(400, { error:"Ogiltig förfrågan." }); }
  const mcname = String(data.mcname || "").trim();
  const message = String(data.message || "").trim();
  if (!/^[A-Za-z0-9_]{1,32}$/.test(mcname)) return reply(400, { error:"Skriv ett giltigt Minecraft-namn." });
  if (message.length > 500) return reply(400, { error:"Meddelandet är för långt." });
  const content = { username:"Ztugan Whitelist", allowed_mentions:{parse:[]}, embeds:[{ title:"Ny whitelist-ansökan", color:0x2463c5, fields:[{name:"Minecraft-namn",value:mcname,inline:true},{name:"Meddelande",value:message || "Inget meddelande",inline:false}], footer:{text:"Granska ansökan och skicka en kod privat om den godkänns."}, timestamp:new Date().toISOString() }] };
  try {
    const result = await fetch(webhook, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(content) });
    if (!result.ok) return reply(502, { error:"Discord kunde inte ta emot ansökan just nu." });
    return reply(200, { ok:true });
  } catch { return reply(502, { error:"Kunde inte kontakta Discord." }); }
};
